USE dataqueue;
DROP TABLE IF EXISTS worker;

CREATE TABLE worker (
  id INT AUTO_INCREMENT  PRIMARY KEY,
  worker_name VARCHAR(250) NOT NULL,
  task_id VARCHAR(10) NOT NULL,
  lst_ping_ts VARCHAR(250) DEFAULT NOT NULL,
  lst_mod_ts VARCHAR(250) DEFAULT NOT NULL
  );
 
  DROP TABLE IF EXISTS task_def;
  CREATE TABLE task_def(
  id INT AUTO_INCREMENT  PRIMARY KEY,
  task_id VARCHAR(5) NOT NULL,
  task_name VARCHAR(10) NOT NULL,
  max_num_workers VARCHAR(5) DEFAULT NOT NULL,
  lst_mod_ts VARCHAR(10) DEFAULT NOT NULL
  );