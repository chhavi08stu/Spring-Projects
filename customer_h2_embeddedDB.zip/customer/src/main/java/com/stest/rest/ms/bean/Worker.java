package com.stest.rest.ms.bean;

import java.sql.Connection;
import java.sql.DriverManager;

public class Worker {
	public static void main(String[] a) throws Exception {
		Connection conn = DriverManager.getConnection("jdbc:h2:D:/545019/Softwares/Setup/MySQL Server 5.5/data/dataqueue", "admin", "admin");
		// add application code here
		System.out.println("connection: "+conn.isClosed());
		conn.close();
	}
}
